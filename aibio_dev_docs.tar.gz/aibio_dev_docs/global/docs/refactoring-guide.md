# 리팩토링 가이드

## 핵심 철학: "작동하는 코드를 더 깨끗하게"

리팩토링은 완벽을 추구하는 것이 아닌, 점진적으로 코드 품질을 개선하는 지속적인 과정입니다.

## 리팩토링 5대 원칙

### 1. ✅ 일관성 우선 원칙 (Consistency First)

#### 네이밍 규칙
```typescript
// ❌ Before: 제각각인 필드명
likes → upvote_count
views → view_count  
is_ai_generated → ai_generated

// ✅ After: 일관된 패턴
- 모든 count는 _count 접미사
- boolean은 is_ 또는 has_ 접두사
- 복수형은 항상 s로 통일
```

#### 파일 구조
```
// ❌ Before: 중구난방 구조
/utils/helpers.ts
/lib/utils.ts
/helpers/format.ts

// ✅ After: 명확한 계층
/lib/
  ├── utils/      # 유틸리티 함수
  ├── helpers/    # 헬퍼 함수
  └── constants/  # 상수 정의
```

### 2. ✅ 타입 중앙화 원칙 (Single Source of Truth)

#### 타입 정의 통합
```typescript
// ❌ Before: 여러 곳에 흩어진 타입
/types/post.ts
/components/PostCard.types.ts
/api/post.types.ts

// ✅ After: 한 곳에서 관리
/types/
  ├── post.ts      // Post 관련 모든 타입
  ├── user.ts      // User 관련 모든 타입
  └── index.ts     // 공통 타입 및 export
```

#### Import 최적화
```typescript
// ❌ Before
import { PostType } from '@/components/PostCard.types'
import { UserType } from '@/api/user.types'

// ✅ After
import { PostType, UserType } from '@/types'
```

### 3. ✅ API 표준화 원칙 (Predictable API)

#### 응답 구조 통일
```typescript
// /lib/api-response.ts
export interface ApiResponse<T = any> {
  success: boolean
  data?: T
  error?: {
    code: string
    message: string
    details?: any
  }
  meta?: {
    page?: number
    total?: number
    timestamp?: string
  }
}

// 모든 API 핸들러에서 사용
export function successResponse<T>(data: T): ApiResponse<T> {
  return { success: true, data }
}

export function errorResponse(code: string, message: string): ApiResponse {
  return { success: false, error: { code, message } }
}
```

#### 에러 처리 표준화
```typescript
// /lib/api-errors.ts
export const ApiErrors = {
  NOT_FOUND: { code: 'NOT_FOUND', message: '리소스를 찾을 수 없습니다' },
  UNAUTHORIZED: { code: 'UNAUTHORIZED', message: '인증이 필요합니다' },
  VALIDATION_ERROR: { code: 'VALIDATION_ERROR', message: '입력값이 올바르지 않습니다' }
} as const
```

#### 데이터베이스 쿼리 표준화
```typescript
// ❌ 위험: Raw SQL은 런타임 에러 가능성
const query = "SELECT * FROM customers WHERE birth_date > ?"  // 컬럼명 오타

// ✅ 안전: ORM은 타입 체크 제공
const customers = await Customer.findAll({
  where: { birthYear: { [Op.gt]: 2000 } }  // 컴파일 타임 체크
})

// Raw SQL이 필요한 경우:
// 1. 반드시 실제 스키마와 대조
// 2. 파라미터 바인딩 사용
// 3. 에러 처리 명확히
```

### 4. ✅ 중복 제거 원칙 (DRY with Balance)

#### 적절한 추상화
```typescript
// ✅ Good: 명확한 중복 제거
// 공통 Card 컴포넌트
export function Card({ children, className, ...props }) {
  return (
    <div className={cn("rounded-lg border p-4", className)} {...props}>
      {children}
    </div>
  )
}

// ❌ Bad: 과도한 추상화
// 너무 generic한 컴포넌트는 오히려 복잡도 증가
export function SuperGenericComponent({ type, variant, size, ... }) {
  // 100줄의 조건문...
}
```

#### 유틸리티 함수 활용
```typescript
// /lib/utils/format.ts
export const formatters = {
  date: (date: Date) => new Intl.DateTimeFormat('ko-KR').format(date),
  number: (num: number) => new Intl.NumberFormat('ko-KR').format(num),
  currency: (amount: number) => `₩${formatters.number(amount)}`
}

// 사용
import { formatters } from '@/lib/utils/format'
const price = formatters.currency(10000) // ₩10,000
```

### 5. ✅ 점진적 개선 원칙 (Incremental Improvement)

#### 단계별 접근
```yaml
1단계 - 현재 상태 파악:
  - 빌드 성공 여부 확인
  - 테스트 통과 여부 확인
  - 주요 문제점 식별

2단계 - 우선순위 설정:
  - 긴급: 빌드 에러, 타입 에러
  - 중요: 중복 코드, 일관성 문제
  - 개선: 성능, 가독성

3단계 - 작은 단위로 실행:
  - 한 번에 한 종류만 수정
  - 각 변경 후 테스트
  - 의미 있는 커밋 단위

4단계 - 검증:
  - 빌드 확인
  - 테스트 실행
  - 수동 테스트
```

### 6. ✅ 컴파일 타임 안정성 원칙 (Compile-time Safety)

#### 타입 안정성 우선
```typescript
// ❌ 런타임에만 발견되는 에러
const customer = {
  customer_id: row.customer_id,
  birth_date: row.birth_date  // 런타임 에러!
}

// ✅ 컴파일 타임에 발견되는 에러
interface CustomerRow {
  customer_id: number
  birth_year: number  // 타입 정의와 불일치 시 즉시 에러
}

const customer: CustomerRow = {
  customer_id: row.customer_id,
  birth_year: row.birth_year  // 타입 체크
}
```

#### ORM 사용 권장
- Raw SQL: 문자열 기반, 런타임 에러
- ORM: 타입 기반, 컴파일 타임 체크
- 필요시 typed-sql 라이브러리 활용

#### 스키마 동기화
```bash
# 스키마 타입 자동 생성
supabase gen types typescript --local > types/database.types.ts
```

### 7. ✅ 컴포넌트 단계적 단순화 원칙 (Progressive Component Simplification)

#### 복잡한 컴포넌트 리팩토링 전략

##### 1. Feature Toggle 방식
```typescript
// 환경 변수로 버전 전환
export function OKRSection() {
  return import.meta.env.VITE_USE_SIMPLE_OKR === 'true'
    ? <SimpleOKRWidget />
    : <OKRTrackingWidget />
}

// 런타임 토글 (개발 환경)
const useFeatureToggle = (feature: string) => {
  const [enabled, setEnabled] = useState(
    localStorage.getItem(`feature:${feature}`) === 'true'
  )
  return { enabled, toggle: () => {
    const newValue = !enabled
    localStorage.setItem(`feature:${feature}`, String(newValue))
    setEnabled(newValue)
  }}
}
```

##### 2. Parallel Implementation 방식
```typescript
// 두 버전을 동시에 유지하며 점진적 이전
export function OKRSection() {
  const { enabled, toggle } = useFeatureToggle('okr-v2')
  
  return (
    <>
      {enabled ? <SimpleOKRWidget /> : <OKRTrackingWidget />}
      {isDevelopment && (
        <button onClick={toggle} className="fixed bottom-4 right-4">
          Toggle OKR Version
        </button>
      )}
    </>
  )
}
```

##### 3. Gradual Replacement 방식
```typescript
// 기능별로 점진적 교체
export function HybridOKRWidget() {
  return (
    <div>
      <SimpleOKRHeader />        {/* 새 버전 */}
      <OKRTrackingContent />     {/* 기존 버전 */}
      <SimpleOKRFooter />        {/* 새 버전 */}
    </div>
  )
}
```

#### 임시 파일 관리 규칙

##### 파일 관리 정책
```yaml
위치: wip/refactor-[기능명] 브랜치
명명: ComponentName.tsx.backup-YYYYMMDD
정리: PR merge 후 1주일 내 삭제
금지: main 브랜치에 *.backup, *.old 파일 직접 커밋

# .gitignore에 추가
*.backup
*.backup-*
*.old
```

##### GitHub Action 자동 검증
```yaml
# .github/workflows/check-backup-files.yml
name: Check Backup Files
on: [pull_request]
jobs:
  check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Check for backup files
        run: |
          if find . -name "*.backup" -o -name "*.old" | grep -q .; then
            echo "❌ Backup files detected. Please remove them."
            exit 1
          fi
```

#### 기능 축소 리팩토링 프로세스

##### 1. 베이스라인 측정 (리팩토링 착수 전 2주 평균)
```typescript
interface BaselineMetrics {
  errorRate: {
    console: number      // 콘솔 에러/1000 페이지뷰
    api: number         // API 실패율 %
    unhandled: number   // Sentry unhandled exceptions/일
  }
  performance: {
    tti: number         // Time to Interactive (ms)
    fcp: number         // First Contentful Paint (ms)
    apiP95: number      // API 응답 시간 P95 (ms)
  }
  coverage: {
    lines: number       // 라인 커버리지 %
    branches: number    // 브랜치 커버리지 %
  }
}
```

##### 2. 단계별 Exit Criteria

```markdown
□ Stage 1 (MVP - 핵심 기능만):
  ✓ 핵심 기능 3개 이상 구현
  ✓ 에러율: 베이스라인 대비 -20% 이상 개선
    - 콘솔 에러: 150 → 120 이하
    - API 실패율: 2.5% → 2.0% 이하
  ✓ 성능: TTI +10% 이내 (2000ms → 2200ms 이하)
  ✓ 테스트 커버리지: 라인 80%, 브랜치 70% 이상

□ Stage 2 (Feature Parity - 기능 동등성):
  ✓ 기존 기능 100% 구현
  ✓ 에러율: 베이스라인 대비 -50% 이상 개선
    - 콘솔 에러: 150 → 75 이하
    - API 실패율: 2.5% → 1.25% 이하
  ✓ 성능: 베이스라인과 동등 이상
  ✓ A/B 테스트 전환율 > 95%
  ✓ 사용자 피드백 수집 및 반영

□ Stage 3 (Migration - 완전 이전):
  ✓ 레거시 코드 제거
  ✓ 에러율: 목표 수준 달성
    - 콘솔 에러: < 50/1000 페이지뷰
    - API 실패율: < 1%
    - Unhandled exceptions: < 5/일
  ✓ 성능: Core Web Vitals 모두 "Good"
  ✓ 문서 업데이트 완료
  ✓ 모니터링 대시보드 설정
```

##### 3. 기능 매핑표 작성
```markdown
| 기존 기능 | MVP | Parity | 비고 |
|----------|-----|--------|------|
| OKR 목록 표시 | ✅ | ✅ | |
| OKR 진행률 차트 | ❌ | ✅ | Stage 2에서 구현 |
| OKR 편집 | ❌ | ✅ | Stage 2에서 구현 |
| 팀별 필터링 | ✅ | ✅ | 단순화된 UI |
| 내보내기 | ❌ | ✅ | Stage 2에서 구현 |
```

## 리팩토링 실행 프로세스

### 1. 준비 단계
```bash
# 브랜치 생성
git checkout -b refactor/[작업명]

# 현재 상태 저장
git add . && git commit -m "refactor: 시작 전 상태"

# 테스트 실행
npm test
npm run build
```

### 2. 실행 단계
```bash
# Claude Code 활용
"컨텍스트 정리"
/compact

"네이밍 규칙 통일"
"likes를 upvote_count로 모두 변경해줘"

# 즉시 확인
npm run build
git commit -m "refactor: likes → upvote_count 변경"

# 다음 작업
"Post 타입들을 /types/post.ts로 통합해줘"

# 컴포넌트 교체 시
git checkout -b wip/refactor-okr
git mv OKRWidget.tsx OKRWidget.tsx.backup-$(date +%Y%m%d)
```

### 3. 검증 단계
```bash
# 전체 빌드 확인
npm run build

# 테스트 실행
npm test

# 타입 체크
npm run type-check

# lint 실행
npm run lint
```

## 실전 체크리스트

### 리팩토링 전
- [ ] 현재 빌드 성공 상태인가?
- [ ] 모든 테스트가 통과하는가?
- [ ] Git 브랜치를 생성했는가?
- [ ] 백업 커밋을 만들었는가?

### 리팩토링 중
- [ ] 한 번에 한 종류만 수정하고 있는가?
- [ ] 매 변경 후 빌드를 확인했는가?
- [ ] 의미 있는 단위로 커밋하고 있는가?
- [ ] /compact로 컨텍스트를 관리하고 있는가?
- [ ] 컴포넌트 교체 시 기능 매핑표를 작성했는가?
- [ ] 백업 파일을 적절히 관리하고 있는가?
- [ ] Feature flag나 조건부 렌더링을 활용하는가?
- [ ] 베이스라인 메트릭을 측정했는가?

### 리팩토링 후
- [ ] 전체 빌드가 성공하는가?
- [ ] 모든 테스트가 통과하는가?
- [ ] 성능 저하가 없는가?
- [ ] 문서를 업데이트했는가?
- [ ] PR 리뷰를 요청했는가?
- [ ] 기존 테스트 케이스 수정이 완료되었는가?
- [ ] 에러율이 목표치를 달성했는가?
- [ ] 백업 파일이 정리되었는가?

## 프로젝트별 리팩토링 우선순위

### 1. 긴급 (반드시 수정)
- 빌드 에러
- 타입 에러
- 테스트 실패
- 보안 취약점

### 2. 중요 (가능한 빨리)
- 중복 코드
- 일관성 없는 네이밍
- 복잡한 조건문
- 긴 함수/클래스

### 3. 개선 (시간 날 때)
- 성능 최적화
- 가독성 개선
- 주석 추가
- 문서화

## AI와 함께하는 리팩토링

### Claude Code 활용 팁
```markdown
1. 명확한 지시:
   "ProductList 컴포넌트의 중복 코드를 제거해줘"
   
2. 단계별 접근:
   "먼저 현재 사용 중인 모든 API 응답 형식을 보여줘"
   "이제 통일된 형식으로 리팩토링해줘"
   
3. 검증 요청:
   "변경 후 영향받는 파일들을 확인해줘"
   "import 경로가 모두 올바른지 확인해줘"
```

### 컨텍스트 관리
```bash
# 긴 세션에서 컨텍스트 유지
/compact  # 주기적으로 실행

# 특정 영역에 집중
"src/components 폴더만 리팩토링 대상으로 봐줘"
```

## 안티패턴 주의사항

### ❌ 피해야 할 것들
1. **Big Bang 리팩토링**: 한 번에 모든 것을 바꾸려는 시도
2. **과도한 추상화**: 재사용을 위한 과도한 일반화
3. **성급한 최적화**: 측정 없는 성능 개선
4. **테스트 없는 리팩토링**: 검증 없는 대규모 변경
5. **에러 숨김**: 에러를 catch하고 빈 값 반환
   ```python
   # ❌ 절대 금지: 에러를 숨기는 코드
   try:
       result = risky_operation()
       return result
   except Exception:
       return []  # 에러를 숨기고 빈 값 반환
   
   # ✅ 올바른 방법: 에러를 적절히 처리
   try:
       result = risky_operation()
       return result
   except SpecificException as e:
       logger.error(f"Operation failed: {e}")
       raise HTTPException(status_code=500, detail=str(e))
   ```
6. **무계획 컴포넌트 교체**: 기능 검증 없이 전체 교체
7. **백업 파일 방치**: *.backup, *.old 파일을 정리하지 않음

### ✅ 권장사항
1. **작은 단위로**: 검증 가능한 작은 변경
2. **측정 기반**: 실제 문제를 해결하는 리팩토링
3. **팀과 소통**: 큰 변경은 사전 논의
4. **문서화**: 왜 변경했는지 기록

## 데이터베이스 스키마 리팩토링

### ⚠️ 특별 주의사항
데이터베이스 스키마 변경은 일반 코드 리팩토링과 다른 주의가 필요합니다.

```bash
# ❌ 절대 금지
- Supabase Studio에서 직접 테이블 수정
- 프로덕션 DB에서 직접 ALTER TABLE 실행

# ✅ 올바른 방법
supabase migration new <변경사항_설명>
supabase db diff  # 변경사항 확인
```

### 스키마 변경 체크리스트
- [ ] 마이그레이션 파일 생성했는가?
- [ ] ORM 모델을 동시에 수정했는가?
- [ ] 프론트엔드 타입도 업데이트했는가?
- [ ] 롤백 SQL을 준비했는가?
- [ ] **전체 코드베이스 검색했는가?**
  ```bash
  # 이전 필드명으로 전체 검색
  grep -r "old_field_name" . --include="*.py" --include="*.ts" --include="*.tsx"
  
  # Raw SQL 쿼리 검색
  grep -r "SELECT.*FROM.*table_name" . --include="*.py"
  ```
- [ ] API 응답 일관성 테스트 추가했는가?
  ```typescript
  // count와 list API가 같은 데이터를 보는지 확인
  test('API 응답 일관성', async () => {
    const count = await api.get('/customers/count')
    const list = await api.get('/customers?limit=1000')
    expect(list.data.length).toBe(count.data.count)
  })
  ```

**🚨 중요**: 데이터베이스 스키마 변경 시 반드시 [배포 체크리스트](./deployment-checklist.md)를 참조하세요.

## 결론

리팩토링은 일회성 이벤트가 아닌 지속적인 개선 과정입니다. 

**핵심 원칙**:
- 🎯 일관성을 최우선으로
- 🔄 점진적이고 안전하게
- ✅ 항상 작동하는 상태 유지
- 🤝 AI를 파트너로 활용
- 🛡️ 스키마 드리프트 방지
- 🚨 에러를 숨기지 말고 처리
- 🔐 컴파일 타임 안정성 추구

"완벽한 코드는 없지만, 더 나은 코드는 항상 가능하다"

## 관련 문서
- [배포 체크리스트](./deployment-checklist.md) - 스키마 드리프트 방지 및 안전한 배포
- [시스템 개요](./system-overview.md) - 전체 아키텍처 이해
- [개발 규칙](./development-rules.md) - 팀 공통 규칙

## 템플릿 및 도구
- [백업 파일 .gitignore 규칙](./templates/gitignore-backup-files.md)
- [GitHub Action 백업 파일 검증](./templates/github-action-check-backup.yml)
- [에러 추적 설정 가이드](./templates/error-tracking-setup.md)