# 🚀 배포 체크리스트 (글로벌 원칙)

> 버전: 1.1.0  
> 최종 업데이트: 2025-06-22  
> 목적: 모든 프로젝트 공통 배포 원칙

## 📢 알림
> 상세한 스키마 드리프트 방지 가이드와 실제 사례는 각 프로젝트의 deployment-checklist.md를 참조하세요.
> 예시: [center/docs/deployment-checklist.md](../center/docs/deployment-checklist.md)

## 📋 목차
1. [공통 배포 원칙](#-공통-배포-원칙)
2. [필수 체크리스트](#-필수-체크리스트)
3. [자동화 도구](#-자동화-도구)

## 🌍 공통 배포 원칙

### 1. 코드와 인프라의 동기화
- **Infrastructure as Code**: 모든 인프라 변경은 코드로 관리
- **Database as Code**: 스키마 변경은 마이그레이션 파일로
- **Config as Code**: 설정은 환경 변수와 설정 파일로

### 2. 배포 순서 원칙
1. **Database First**: 스키마 변경 먼저 적용
2. **Backend Second**: API 서버 배포
3. **Frontend Last**: UI 배포
4. **Rollback Ready**: 각 단계마다 롤백 가능

### 3. 검증 자동화
- **CI/CD Pipeline**: 모든 변경사항 자동 검증
- **Smoke Tests**: 핵심 기능 정상 작동 확인
- **Health Checks**: 배포 후 서비스 상태 모니터링

## ✅ 필수 체크리스트

### 배포 전
- [ ] 모든 테스트 통과 (Unit, Integration, E2E)
- [ ] 코드 리뷰 완료 및 승인
- [ ] 문서 업데이트 완료
- [ ] 환경 변수 확인
- [ ] 데이터베이스 백업

### 배포 중
- [ ] 스키마 마이그레이션 실행
- [ ] 백엔드 서비스 배포
- [ ] 프론트엔드 배포
- [ ] Health check 통과

### 배포 후
- [ ] 모니터링 대시보드 확인
- [ ] 에러 로그 확인
- [ ] 사용자 피드백 수집
- [ ] 성능 메트릭 확인

## 🔧 자동화 도구

### GitHub Actions 예시
```yaml
name: Deployment Pipeline
on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Run tests
        run: npm test
        
      - name: Build
        run: npm run build
        
      - name: Deploy
        run: npm run deploy
        
      - name: Health check
        run: curl -f $PROD_URL/health || exit 1
```

### 모니터링 설정
- **APM**: NewRelic, Datadog, 또는 Sentry
- **Logs**: CloudWatch, LogDNA, 또는 Papertrail
- **Metrics**: Prometheus + Grafana
- **Alerts**: PagerDuty 또는 Slack

## 🔗 관련 문서
- [Git Workflow](./git-workflow.md) - 브랜치 전략과 배포 프로세스
- [스키마 동기화 자동화](./schema-sync-automation.md) - DB 스키마 자동화
- [리팩토링 가이드](./refactoring-guide.md) - 안전한 코드 변경

## 📚 프로젝트별 상세 가이드
각 프로젝트의 특화된 배포 체크리스트를 참조하세요:
- [center/docs/deployment-checklist.md](../center/docs/deployment-checklist.md) - AIBIO 센터 프로젝트

---

*이 문서는 모든 프로젝트에 적용되는 공통 배포 원칙입니다.*
*프로젝트별 상세 사항은 각 프로젝트의 문서를 참조하세요.*