# 🚀 Git Workflow Guide
> Version: 1.0.0  
> Last updated: 2025-06-22  
> Scope: **모든 저장소** - frontend, backend, infra

## 1. Branch Strategy

| Branch | Purpose | Rule |
|--------|---------|------|
| `main` | 배포용 • 항상 **deployable** | CI ✓ / CD to Railway |
| `feat/*` | 신규 기능 | 1 작업 = 1 PR |
| `fix/*` | 버그 수정 | 긴급 패치도 동일 |
| `chore/*` | 문서/설정 | 코드 無 |
| `refactor/*` | 리팩토링 | 기능 변경 없이 구조 개선 |

*기능 > 리팩터링* 처럼 하위 prefix를 추가해도 무방 (`feat/refactor/*`).

## 2. Commit Message Convention

```
type(scope): summary

- body (optional)
- more details
```

- **type**: feat, fix, refactor, docs, test, chore
- **scope**: users, reservation, payments, auth, ci, ...
- **summary**: 50자 이내; 한글 OK

### 예시
✅ 좋은 예:
- `feat(reservation): add trailing-slash support`
- `fix(auth): 로그인 토큰 만료 시간 수정`
- `docs: API 문서 업데이트`

❌ 나쁜 예:
- `update` (타입과 내용이 불명확)
- `fix bug` (어떤 버그인지 불명확)

### "체크포인트" 커밋 `vibe:`
프로토타입·WIP 중 빠른 스냅샷이 필요할 때 사용

```bash
git commit -am "vibe: spike - playground for sms api"
git commit -am "vibe: [기능명] 진행중"
```

> 규칙: 24시간 내 정식 커밋으로 대체 권장

## 3. Pull Request Flow

### 3.1 PR 생성
1. **Draft PR** 바로 생성 → 공유·리뷰 시작
2. PR 제목: `[Type] 간단한 설명`
3. PR 템플릿 작성 (아래 참조)

### 3.2 Merge 조건
- 최소 1 approve
- CI 모든 체크 통과 (녹색)
- 충돌 해결 완료

### 3.3 Merge 전략
- **Squash and merge** (기본)
- 커밋 히스토리가 중요한 경우만 일반 merge

### 3.4 PR Template
```markdown
## 📋 변경사항
- 무엇을 변경했는지 간단히 설명

## 🤔 왜 필요한가
- 변경이 필요한 이유

## 🧪 테스트
- [ ] 단위 테스트 추가/수정
- [ ] 통합 테스트 확인
- [ ] 로컬에서 수동 테스트 완료

## 🚀 배포 영향
- [ ] DB 마이그레이션 필요
- [ ] 환경 변수 추가
- [ ] Breaking change 여부
```

## 4. Rebase & History

### 4.1 Feature 브랜치 최신화
```bash
# main 브랜치의 최신 변경사항 가져오기
git checkout main
git pull origin main

# feature 브랜치로 이동하여 rebase
git checkout feat/my-feature
git rebase main
```

### 4.2 Force Push
- `git push --force-with-lease` 사용 (더 안전)
- 단, 다른 사람이 작업 중인 브랜치는 금지

### 4.3 커밋 정리
```bash
# 최근 3개 커밋 정리
git rebase -i HEAD~3
```

## 5. Release & Tagging

### 5.1 태그 형식
- `v1.0.0` - 메이저 릴리즈
- `v1.1.0` - 마이너 릴리즈
- `v1.1.1` - 패치/핫픽스

### 5.2 릴리즈 프로세스
```bash
# 태그 생성
git tag -a v1.0.0 -m "Release version 1.0.0"

# 태그 푸시
git push origin v1.0.0
```

## 6. 긴급 수정 (Hotfix)

```bash
# main에서 직접 브랜치 생성
git checkout -b fix/critical-bug main

# 수정 후 바로 PR
# 승인 후 main에 merge
# 태그 생성: v1.0.1
```

## 7. 협업 규칙

### 7.1 코드 리뷰
- 24시간 내 리뷰 응답
- 건설적인 피드백
- "왜"를 설명하는 주석 추가

### 7.2 충돌 해결
- rebase 중 충돌 시 팀원과 상의
- 큰 변경은 사전 공지

### 7.3 브랜치 정리
- merge된 브랜치는 즉시 삭제
- 3주 이상 오래된 브랜치는 정리 대상

---

## 🔗 관련 문서
- [개발 규칙](../center/docs/development-rules.md)
- [배포 체크리스트](deployment-checklist.md)
- [테스트 전략](../center/docs/test-strategy.md)

_문의사항은 @dev-lead 또는 #dev-workflow 채널로_